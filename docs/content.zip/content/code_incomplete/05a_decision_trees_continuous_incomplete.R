# Task: copy code from previous binary file and modify it for the continuous problem
# (note: you will need to replace logistic regression with linear regression)